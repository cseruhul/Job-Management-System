-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 25, 2020 at 06:36 PM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.3.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_main`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_category`
--

CREATE TABLE `tbl_category` (
  `id` int(11) NOT NULL,
  `name` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_category`
--

INSERT INTO `tbl_category` (`id`, `name`) VALUES
(1, 'Programmer'),
(2, 'Web Designer'),
(3, 'Web Developer'),
(6, 'Graphic Designer'),
(7, 'Animation'),
(8, 'C Sharp'),
(9, 'Python'),
(10, 'BCS');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_contact`
--

CREATE TABLE `tbl_contact` (
  `id` int(11) NOT NULL,
  `firstname` varchar(255) NOT NULL,
  `lastname` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_contact`
--

INSERT INTO `tbl_contact` (`id`, `firstname`, `lastname`, `email`, `body`, `status`, `date`) VALUES
(8, 'Ruhul', 'Amin', 'ruhul.computer12@gmail.com', 'This is a testing message... ... ...', 1, '2020-01-23 10:50:43'),
(9, 'Biddut', 'Ali', 'ar.ruhul2016@gmail.com', 'This is second testing message... ... ...', 1, '2020-01-23 10:50:43'),
(11, 'Md.', 'Ruhul', 'aarrruuhul@gmail.com', 'Hi,\r\nI am Md. Ruhul. I need a job. I am a Web developer. Can you help me?', 1, '2020-01-23 12:47:51'),
(12, 'Engr.', 'Md. Ruhul Amin', 'engr.ruhul@yahoomail.com', 'Hii,\r\nThis is a Text message for testing..... :)', 1, '2020-01-23 13:57:47'),
(13, 'Md', 'Shohan', 'shohanduet@gmail.com', 'Test message', 1, '2020-01-24 04:35:55'),
(14, 'Alimun', 'Biswas', 'alimunduet@gmail.com', 'Hi, I am Alimun. I am an Engineer', 1, '2020-01-25 07:45:05'),
(15, 'Ruhul', 'Amin', 'ruhul.computer12@gmail.com', 'afasdfasdf', 1, '2020-01-25 12:36:02');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_footer`
--

CREATE TABLE `tbl_footer` (
  `id` int(11) NOT NULL,
  `note` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_footer`
--

INSERT INTO `tbl_footer` (`id`, `note`) VALUES
(1, 'All Right reserved || CSE, DUET');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_gender`
--

CREATE TABLE `tbl_gender` (
  `id` int(11) NOT NULL,
  `gender` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_gender`
--

INSERT INTO `tbl_gender` (`id`, `gender`) VALUES
(1, 'Male'),
(2, 'Female'),
(3, 'Both Male and Female');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_govt`
--

CREATE TABLE `tbl_govt` (
  `id` int(11) NOT NULL,
  `one` varchar(255) NOT NULL,
  `l_one` varchar(255) NOT NULL,
  `two` varchar(255) NOT NULL,
  `l_two` varchar(255) NOT NULL,
  `three` varchar(255) NOT NULL,
  `l_three` varchar(255) NOT NULL,
  `four` varchar(255) NOT NULL,
  `l_four` varchar(255) NOT NULL,
  `five` varchar(255) NOT NULL,
  `l_five` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_govt`
--

INSERT INTO `tbl_govt` (`id`, `one`, `l_one`, `two`, `l_two`, `three`, `l_three`, `four`, `l_four`, `five`, `l_five`) VALUES
(1, 'NTRCA', 'http://www.ntrca.gov.bd/', 'PGCB', 'http://pgcb.gov.bd/', 'NESCO', 'http://nesco.gov.bd/', 'BWDB', 'https://www.bwdb.gov.bd/', 'NPO', 'http://www.npo.gov.bd/');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_post`
--

CREATE TABLE `tbl_post` (
  `id` int(11) NOT NULL,
  `cat` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `company_name` varchar(255) NOT NULL,
  `vacancy` int(255) NOT NULL,
  `employment_status` varchar(255) NOT NULL,
  `educational_requirements` varchar(255) NOT NULL,
  `experience_requirements` varchar(255) NOT NULL,
  `job_location` varchar(255) NOT NULL,
  `slary` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `gender` varchar(255) NOT NULL,
  `age` varchar(255) NOT NULL,
  `application_deadline` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `tags` varchar(255) NOT NULL,
  `published_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `author` varchar(255) NOT NULL,
  `userid` varchar(255) NOT NULL,
  `status` varchar(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_post`
--

INSERT INTO `tbl_post` (`id`, `cat`, `title`, `company_name`, `vacancy`, `employment_status`, `educational_requirements`, `experience_requirements`, `job_location`, `slary`, `body`, `gender`, `age`, `application_deadline`, `image`, `tags`, `published_date`, `author`, `userid`, `status`) VALUES
(16, 2, 'UI/ UX Front End Developer', 'SK Associates', 1, 'Full-time', 'Bachelor of Computer Application (BCA)', 'At least 3 year(s)', 'Sylhet, Sylhet (Sylhet Sadar)', 'Negotiable', '<p>Job context: As a front end developer, you must be a UI/UX expert with latest technology knowledge and experience. You must be able to write clean codes. Job Responsibilities: 1. You must be a quick thinker and able to visualise a client\'s need. 2. Draw up UI and UX strategies based on our target goals. 3. Create and maintain digital assets, such as interface design files, wireframes, and interactive mockups using InVision/Zapline/Figma etc. 4. Design, build, and maintain highly reusable JavaScript, HTML and CSS code. 5. Highly skilled in PSD to HTML and need to work with development team to process HTML/CSS based on the software requirements. 6. Communicates with the client and project teams &amp; explains progress on the development effort. 7. Need to have knowledge to prepare theme for WordPress and other CMS e.g. Magneto, Joomla, Drupal etc.You will be required to work under pressure and work to deliver. Additional Requirements: 1. Age at least 25 years 2. Both males and females are allowed to apply 3. The applicants should have experience in the following area(s): 4. Content Developer, Graphic Designer, HTML &amp; CSS, Project designing, Quality Assurance/ Quality Control, UI design, UX Designer, Web Developer/ Web Designer 5. The applicants should have experience in the following business area(s): 6. E-commerce, IT Enabled Service, Software Company, Web Media/Blog Compensation &amp; Other Benefits: 1. Salary Review: Yearly 2. Festival Bonus: 2 3. 26 days holidays which includes casual and Government holiday periods.</p>', '2', '0', 'Jan 13, 2020', 'upload/236ecdabea.jpg', 'PHP, CSS', '2020-01-17 05:20:48', 'admin', '2', '1'),
(17, 1, 'C Programmer Needed', 'AR Technology', 4, 'Full Time', 'Bachelor of Science on CSE', 'Minimum 3 years experience', 'DUET, Gazipur.', 'On Discussion', '<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.<br />Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>', '1', 'Minimum 23 years old.', '14.02.2020', 'upload/91cea4fd8b.jpg', 'C, C++, java, python, Ruby', '2020-01-17 05:20:48', 'Shohan', '5', '1'),
(18, 2, 'Webdesigner needed', 'AR Technology', 4, 'Full Time', 'Bachelor of Science on CSE', 'Minimum 3 years experience', 'DUET, Gazipur.', 'On Discussion', '<p>$div = explode(\'.\', $file_name);<br /> $file_ext = strtolower(end($div));<br /> $unique_image = substr(md5(time()), 0, 10).\'.\'.$file_ext;<br />$uploaded_image = \"upload/\".$unique_image;</p>\r\n<p>$div = explode(\'.\', $file_name);<br /> $file_ext = strtolower(end($div));<br /> $unique_image = substr(md5(time()), 0, 10).\'.\'.$file_ext;<br />$uploaded_image = \"upload/\".$unique_image;</p>\r\n<p>$div = explode(\'.\', $file_name);<br /> $file_ext = strtolower(end($div));<br /> $unique_image = substr(md5(time()), 0, 10).\'.\'.$file_ext;<br />$uploaded_image = \"upload/\".$unique_image;</p>\r\n<p>$div = explode(\'.\', $file_name);<br /> $file_ext = strtolower(end($div));<br /> $unique_image = substr(md5(time()), 0, 10).\'.\'.$file_ext;<br />$uploaded_image = \"upload/\".$unique_image;</p>\r\n<p>$div = explode(\'.\', $file_name);<br /> $file_ext = strtolower(end($div));<br /> $unique_image = substr(md5(time()), 0, 10).\'.\'.$file_ext;<br />$uploaded_image = \"upload/\".$unique_image;</p>\r\n<p>$div = explode(\'.\', $file_name);<br /> $file_ext = strtolower(end($div));<br /> $unique_image = substr(md5(time()), 0, 10).\'.\'.$file_ext;<br /> $uploaded_image = \"upload/\".$unique_image;</p>', '2', 'Minimum 23 years old.', '14.02.2020', 'upload/9f4d30aeab.jpg', 'C, C++, java, python, Ruby', '2020-01-17 05:20:48', 'admin', '2', '1'),
(20, 1, 'Python developer required', 'CSE engineers.com', 5, 'Full Time', 'Bachelor of Science on CSE', 'Minimum 3 years experience', 'Dhaka', 'On Discussion', '<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.<br />Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>', '1', 'Minimum 23 years old.', '14.02.2020', 'upload/510df769f0.png', 'python', '2020-01-17 05:20:48', 'admin', '2', '1'),
(21, 1, 'Microcontroller expert needed', 'RC Technologies', 2, 'part-time', 'Bachelor of Science on CSE/EEE', 'NO', 'Kushtia, Dhaka, Bangladesh', 'On Discussion', '<p>Hi,</p>\r\n<p>I have a display led light for my shop that needs a new Attiny85 chip programmed to work the lights. I fried the other chip, including pic of the light..chip needs to be programmed to alternate and fade between the two light.</p>\r\n<p>&nbsp;</p>\r\n<p>Thx</p>\r\n<p>Ian</p>\r\n<p class=\"PageProjectViewLogout-detail-tags\"><span>Skills:</span>&nbsp;Electronics,&nbsp;C Programming,&nbsp;Microcontroller,&nbsp;Electrical Engineering,&nbsp;C++ Programming</p>\r\n<p class=\"PageProjectViewLogout-detail-tags\"><span>See more:</span>&nbsp;need programmer regular work,&nbsp;i have an html email template i need modified to work with mailchimp,&nbsp;i need data entry work to be done,&nbsp;i need data entry work,&nbsp;i need programmer for contact form,&nbsp;i need programmer write code,&nbsp;i need salesman duabi work,&nbsp;i need data entry work in home,&nbsp;i need freelance 3d work in dubai,&nbsp;i need online engineering work,&nbsp;i need programmer,&nbsp;i need programmer a site in india,&nbsp;i need programmer for a project,&nbsp;i need programmer paraphrasing,&nbsp;i need programmer to debug my code,&nbsp;i need sanitary engineer work,&nbsp;i need someone to work html uae,&nbsp;i need web design work,&nbsp;i need html 5 work,&nbsp;House plan for 80ft X 30ft Plot size -- 2 I need some design work. house plan for 80ft 30ft plot according vaastu 80ft side is n</p>', '1', 'Minimum 23 years old.', '14.02.2020', 'upload/cf8d31371c.jpg', 'C, C++, java, python, Ruby', '2020-01-23 06:20:56', 'Shohan', '5', '1'),
(22, 10, 'A teacher needed for job coaching', 'Brilliant Coaching Center', 3, 'part-time', 'Bachelor of Science on CSE/EEE', 'NO', 'DUET, Gazipur.', 'On Discussion', '<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>', 'Select Gender', 'Minimum 20 years old.', '14.02.2020', 'upload/e9cfefbde7.jpg', 'C, C++, java, python, Ruby', '2020-01-24 20:28:00', 'admin', '2', '1'),
(23, 1, 'This is testing post', 'Brilliant Coaching Center', 3, 'Full Time', 'Bachelor of Science on CSE', 'Minimum 3 years experience', 'DUET, Gazipur.', 'On Discussion', '<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>', '1', 'Minimum 23 years old.', '14.02.2020', 'upload/e087363b36.png', 'C, C++, java, python, Ruby', '2020-01-24 20:33:56', 'admin', '2', '1'),
(24, 1, 'A Java Programmer Needed', 'CSE engineers.com', 4, 'Full Time', 'Bachelor of Science on CSE', 'Minimum 3 years experience', 'Kushtia, Dhaka, Bangladesh', 'On Discussion', '<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>', '1', 'Minimum 23 years old.', '14.02.2020', 'upload/c08622a17d.jpg', 'C, C++, java, python, Ruby', '2020-01-25 02:48:52', 'admin', '2', '1'),
(25, 9, 'A Programmer Needed', 'AR Technology', 4, 'Full Time', 'Bachelor of Science on CSE/EEE', 'Minimum 3 years experience', 'DUET, Gazipur.', 'On Discussion', '<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>', 'Select Gender', 'Minimum 23 years old.', '14.02.2020', 'upload/2d23a26265.jpg', 'C, C++, java, python, Ruby', '2020-01-25 02:50:48', 'admin', '2', '1'),
(26, 7, 'Animation expert needed', 'AR Technology', 5, 'part-time', 'Bachelor of Science on CSE', 'NO', 'DUET, Gazipur.', 'On Discussion', '<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>', 'Select Gender', 'Minimum 23 years old.', '14.02.2020', 'upload/d96e3d3cae.jpg', 'Animation, Graphics', '2020-01-25 03:48:11', 'alimun', '3', '1'),
(27, 3, 'Web designer and developer needed', 'RC Technologies', 4, 'part-time', 'Bachelor of Science on CSE', 'Minimum 3 years experience', 'DUET, Gazipur.', 'On Discussion', '<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>', '3', 'Minimum 23 years old.', '14.02.2020', 'upload/b879147d30.jpg', 'html, css, php, javascript, mysqli', '2020-01-25 00:02:17', 'alimun', '3', '1'),
(28, 3, 'Web designer and developer needed', 'RC Technologies', 4, 'Full Time', 'Bachelor of Science on CSE', 'Minimum 3 years experience', 'DUET, Gazipur.', 'On Discussion', '<p>RC TechnologiesRC TechnologiesRC TechnologiesRC TechnologiesRC TechnologiesRC TechnologiesRC TechnologiesRC TechnologiesRC TechnologiesRC TechnologiesRC TechnologiesRC TechnologiesRC TechnologiesRC TechnologiesRC TechnologiesRC TechnologiesRC TechnologiesRC TechnologiesRC TechnologiesRC TechnologiesRC TechnologiesRC TechnologiesRC TechnologiesRC TechnologiesRC TechnologiesRC TechnologiesRC TechnologiesRC TechnologiesRC TechnologiesRC TechnologiesRC TechnologiesRC TechnologiesRC Technologies</p>', '3', 'Minimum 23 years old.', '14.02.2020', 'upload/cba8cb761f.jpg', 'html, css', '2020-01-25 00:05:45', 'alimun', '3', '1'),
(29, 8, 'A Programmer Needed', 'Desktop.com', 10, 'Full Time', 'Bachelor of Science on CSE', 'Minimum 3 years experience', 'DUET, Gazipur.', 'On Discussion', '<p>à¦•à¦¨à§à¦¸à¦¾à¦°à§à¦Ÿ à¦®à¦¿à¦°à§à¦œà¦¾à¦ªà§à¦° à¦•à¦²à§‡à¦œ, à¦Ÿà¦¾à¦‚à¦—à¦¾à¦‡à¦²à¥¤(à§¨à§¦à§¨à§¦/à§¨à§ª/à§¦à§§) à¦†à¦œà¦•à§‡à¦° à¦¸à§à¦ªà§‡à¦¶à¦¾à¦² à¦—à¦¾à¦¨à¦Ÿà¦¿ .... (à¦¯à§‡à¦¦à¦¿à¦¨ à¦¬à¦¨à§à¦§à§ à¦šà¦²à§‡ à¦¯à¦¾à¦¬à§‹) à¦—à¦¾à¦¨à§‡à¦° à¦¸à¦‚à¦–à§à¦¯à¦¾ à¦›à¦¿à¦² à¦®à§‹à¦Ÿ à§§à§§ à¦Ÿà¦¿ à§§/à¦²à§‡à¦‡à¦¸ à¦«à¦¿à¦¤à¦¾ à¦²à§‡à¦‡à¦¸ à§¨/à¦•à¦¬à¦¿à¦¤à¦¾ à§©/à¦—à§à¦°à§ à¦˜à¦° à¦¬à¦¾à¦¨à¦¾à¦‡à¦²à¦¾ à¦•à¦¿ à¦¦à¦¿à§Ÿà¦¾ à§ª/à¦¸à§à¦²à¦¤à¦¾à¦¨à¦¾ à¦¬à¦¿à¦¨à¦¿à§Ÿà¦¾à¦¨à¦¾ à§«/à¦®à¦¾ à§¬/à¦¦à¦¿à¦“à§Ÿà¦¾à¦¨à¦¾ à¦¦à¦¿à¦“à§Ÿà¦¾à¦¨à¦¾ à§­/à¦¯à§‡ à¦¦à¦¿à¦¨ à¦¬à¦¨à§à¦§à§ à¦šà¦²à§‡ à¦¯à¦¾à¦¬à§‡ à§®/ à¦¤à§‹à¦° à¦ªà§à¦°à§‡à¦®à§‡à¦¤à§‡ à¦…à¦¨à§à¦§ à¦¹à¦²à¦¾à¦® à§¯/à¦à¦¾à¦•à¦¾à¦¨à¦¾à¦•à¦¾ à§§à§¦/à¦¸à§à¦¨à§à¦¦à¦°à§€à¦¤à¦®à¦¾ à§§à§§/à¦­à¦¿à¦—à¦¿ à¦­à¦¿à¦—à¦¿</p>', 'Select Gender', 'Minimum 23 years old.', '14.02.2020', 'upload/5f97fd656b.jpg', 'C#, Visual Programming', '2020-01-25 06:11:17', 'alimun', '3', '1'),
(30, 6, 'A graphic designer requires', 'CSE engineers.com', 4, 'part-time', 'Not required', 'NO', 'DUET, Gazipur.', 'On Discussion', '<p>On DiscussionOn DiscussionOn DiscussionOn DiscussionOn DiscussionOn DiscussionOn DiscussionOn DiscussionOn DiscussionOn DiscussionOn DiscussionOn DiscussionOn DiscussionOn DiscussionOn DiscussionOn DiscussionOn DiscussionOn DiscussionOn DiscussionOn DiscussionOn DiscussionOn DiscussionOn DiscussionOn DiscussionOn DiscussionOn DiscussionOn DiscussionOn DiscussionOn DiscussionOn DiscussionOn DiscussionOn DiscussionOn DiscussionOn DiscussionOn Discussion</p>', '3', 'Minimum 20 years old.', '14.02.2020', 'upload/d1fbd35a71.jpg', 'Animation, Graphics', '2020-01-25 07:49:45', 'alimun', '3', '1'),
(31, 7, 'A animation creator needed', 'AR Technology', 4, 'Full Time', 'Bachelor of Science on CSE', 'Minimum 3 years experience', 'Dhaka', 'On Discussion', '<p>Minimum 3 years experienceMinimum 3 years experienceMinimum 3 years experienceMinimum 3 years experienceMinimum 3 years experienceMinimum 3 years experienceMinimum 3 years experienceMinimum 3 years experienceMinimum 3 years experienceMinimum 3 years experienceMinimum 3 years experienceMinimum 3 years experienceMinimum 3 years experienceMinimum 3 years experienceMinimum 3 years experienceMinimum 3 years experienceMinimum 3 years experienceMinimum 3 years experienceMinimum 3 years experienceMinimum 3 years experienceMinimum 3 years experienceMinimum 3 years experienceMinimum 3 years experienceMinimum 3 years experienceMinimum 3 years experienceMinimum 3 years experienceMinimum 3 years experienceMinimum 3 years experienceMinimum 3 years experienceMinimum 3 years experienceMinimum 3 years experience</p>', '3', 'Minimum 23 years old.', '14.02.2020', 'upload/287b2bf0ea.jpg', 'Animation, Graphics', '2020-01-25 08:56:02', 'admin', '2', '1');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE `tbl_user` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `username` varchar(150) NOT NULL,
  `password` varchar(32) NOT NULL,
  `email` varchar(255) NOT NULL,
  `details` text NOT NULL,
  `role` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`id`, `name`, `username`, `password`, `email`, `details`, `role`) VALUES
(2, 'Ruhul Amin', 'admin', '202cb962ac59075b964b07152d234b70', 'ruhul.computer12@gmail.com', '<p>Hey,</p>\r\n<p>I am Ruhul Amin. And I am the admin of this site.</p>', 0),
(3, 'Alimun Rajon', 'alimun', '827ccb0eea8a706c4c34a16891f84e7b', 'alimun.cse@gmail.com', '<p>Hi,</p>\r\n<p>I am an employee.</p>\r\n<p>I am Author</p>', 1),
(5, 'Md. Shohanur Rahman', 'Shohan', '202cb962ac59075b964b07152d234b70', 'shohan.duet@gmail.com', '<p>Hi,</p>\r\n<p>I am shohan . I am the editor of this site.</p>', 2);

-- --------------------------------------------------------

--
-- Table structure for table `title_slogan`
--

CREATE TABLE `title_slogan` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `slogan` varchar(255) NOT NULL,
  `logo` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `title_slogan`
--

INSERT INTO `title_slogan` (`id`, `title`, `slogan`, `logo`) VALUES
(1, 'Find Your Job here', 'Find your passion here. And make your life as your dream', 'upload/logo.png');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_category`
--
ALTER TABLE `tbl_category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_contact`
--
ALTER TABLE `tbl_contact`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_footer`
--
ALTER TABLE `tbl_footer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_gender`
--
ALTER TABLE `tbl_gender`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_govt`
--
ALTER TABLE `tbl_govt`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_post`
--
ALTER TABLE `tbl_post`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_user`
--
ALTER TABLE `tbl_user`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `title_slogan`
--
ALTER TABLE `title_slogan`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_category`
--
ALTER TABLE `tbl_category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `tbl_contact`
--
ALTER TABLE `tbl_contact`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `tbl_footer`
--
ALTER TABLE `tbl_footer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_gender`
--
ALTER TABLE `tbl_gender`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tbl_govt`
--
ALTER TABLE `tbl_govt`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_post`
--
ALTER TABLE `tbl_post`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `tbl_user`
--
ALTER TABLE `tbl_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `title_slogan`
--
ALTER TABLE `title_slogan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
